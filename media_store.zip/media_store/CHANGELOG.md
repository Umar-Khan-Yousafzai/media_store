## 1.0.0

- forked from [image_gallery_saver](https://github.com/hui-z/image_gallery_saver)
